package gameshopcrud;

import java.awt.geom.Ellipse2D;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class GameShopCRUD {

    public static void main(String[] args) throws SQLException {
        Connection conn = null;
        try {

            conn = getConnection();
            Scanner sc = new Scanner(System.in);
            System.out.println("Sta zelite da uradite:");
            System.out.println("0. Izadjete iz programa:");
            System.out.println("1. Ubacite novu vrijednost u bazu");
            System.out.println("2. Pkazite vrijednosti iz baze:");
            System.out.println("3. Updejtate postojecu vrijednost:");
            System.out.println("4. Izbrisite vrijednost:");
            int x = sc.nextInt();

            while (x != 0) {

                Statement stmt = conn.createStatement();
                switch (x) {
                    case 1:
                        insertFunction();
                        break;
                    case 2:
                        selectFunction();
                        break;
                    case 3:
                        updateFunction();
                        break;
                    case 4:
                        deleteFunction();
                        break;
                    default:
                        System.out.println("nepoznata komanada,");
                        break;

                }
                System.out.println("Sta zelite da uradite:");
                System.out.println("0. Izadjite iz programa:");
                System.out.println("1. Insertajte novu vrijednost u bazu");
                System.out.println("2. Pokazete trenutne vrijednosti baze:");
                System.out.println("3. Updejtate postojecu vrijednost:");
                System.out.println("4. Izbrisite vrijednost:");
                x = sc.nextInt();
            }
            System.out.println("Hvala na koristenju");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                conn.close();
            }
        }

    }

    private static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/gameshop";
        String username = "root";
        String password = "Mamkox455521";
        Connection conn = DriverManager.getConnection(url, username, password);
        System.out.println("Connected");
        return conn;
    }

    private static void insertFunction() throws SQLException {
        String Insert;
        Connection conn = getConnection();
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Sta zelite da uradite:");
        System.out.println("0 Prekinete unos:");
        System.out.println("1 Uneste novi zanr:");
        System.out.println("2 Unesete novu igricu:");
        System.out.println("3 Unesete novog developera:");
        System.out.println("4 Unesete novog publishera:");
        int x1 = sc.nextInt();
        while (x1 != 0) {
            switch (x1) {
                case 1:

                    Insert = "INSERT INTO genre(genre_name) values(?)";

                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Insert);
                        System.out.println("Unesite ime zanra");
                        ps1.setString(1, sc.next());
                        ps1.executeUpdate();
                        System.out.println("Unijeli ste novi zanr");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 2:
                    Insert = "INSERT INTO game(game_name,game_price,game_description,game_rating,developer_id,publisher_id,genre_id) values(?,?,?,?,?,?,?)";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Insert);
                        System.out.println("Unesite ime igrice:");
                        ps1.setString(1, sc.next());
                        System.out.println("Unesite cijenu igrice:");
                        ps1.setString(2, sc.next());
                        System.out.println("Unesite opis igrice:");
                        ps1.setString(3, sc.next());
                        System.out.println("Unesite rating igrice (od 1-5):");
                        ps1.setFloat(4, sc.nextFloat());
                        System.out.println("Unesite developer id:");
                        ps1.setInt(5, sc.nextInt());
                        System.out.println("Unesite publisher id:");
                        ps1.setInt(6, sc.nextInt());
                        System.out.println("Unesite genre id:");
                        ps1.setInt(7, sc.nextInt());
                        ps1.executeUpdate();
                        System.out.println("Unijeli ste novu igricu");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 3:
                    Insert = "INSERT INTO developer(dev_name,description) values(?,?)";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Insert);
                        System.out.println("Unesite naziv developera:");
                        ps1.setString(1, sc.next());
                        System.out.println("Unesite kratak opis developera:");
                        ps1.setString(2, sc.next());
                        ps1.executeUpdate();
                        System.out.println("Unijeli ste novog developera");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 4:
                    Insert = "INSERT INTO publisher(pub_name,description) values(?,?)";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Insert);
                        System.out.println("Unesite naziv publishera:");
                        ps1.setString(1, sc.next());
                        System.out.println("Unesite kratak opis publishera:");
                        ps1.setString(2, sc.next());
                        ps1.executeUpdate();
                        System.out.println("Unijeli ste novog publishera");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                default:
                    System.out.println("Niste unijeli validan broj");
                    break;
            }
            System.out.println("0 Prekinete unos:");
            System.out.println("1 Uneste novi zanr:");
            System.out.println("2 Unesete novu igricu:");
            System.out.println("3 Unesete novog developera:");
            System.out.println("4 Unesete novog publishera:");
            x1 = sc.nextInt();
        }

    }

    private static void selectFunction() throws SQLException {
        Connection conn = getConnection();
        String Select;
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("0 Prekinete akciju:");
        System.out.println("1 Prikazite zanrove:");
        System.out.println("2 Prikazi igrice:");
        System.out.println("3 Prikazi developere:");
        System.out.println("4 Prikazite publishere:");

        int x1 = sc.nextInt();
        while (x1 != 0) {
            switch (x1) {
                case 1:
                    Select = "select * from genre";
                    try (PreparedStatement pss = conn.prepareStatement(Select);) {
                        ResultSet rs = pss.executeQuery();
                        System.out.println("ID" + "\t Game name");
                        while (rs.next()) {
                            System.out.println(rs.getInt("id_genre") + "\t " + rs.getString("genre_name"));
                        }

                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 2:
                    Select = "select gm.id_game,gm.game_name,gm.game_price,gm.game_rating,"
                            + "genre.genre_name,developer.dev_name,publisher.pub_name,gm.game_description "
                            + "from (((game as gm join genre on gm.genre_id = genre.id_genre )join developer on gm.developer_id "
                            + "=developer.id_developer )join publisher on gm.publisher_id =publisher.id_publisher)";
                    try (PreparedStatement pss = conn.prepareStatement(Select);) {
                        ResultSet rs = pss.executeQuery();
                        System.out.println("ID" + "\t\t Game name" + "\t\t Game price" + "\t\t game rating"
                                + "\t\t genre" + "\t\t Developer name" + "\t\t Publisher name" + "\t\t Description");

                        while (rs.next()) {
                            System.out.println(rs.getInt("id_game") + "\t\t " + rs.getString("game_name") + "\t\t "
                                    + rs.getString("game_price") + "\t\t\t " + rs.getFloat("game_rating") + "\t\t\t "
                                    + rs.getString("genre_name") + "\t " + rs.getString("dev_name") + "\t\t "
                                    + rs.getString("pub_name") + "\t " + rs.getString("game_description"));
                        }

                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 3:
                    Select = "select * from developer";
                    try (PreparedStatement pss = conn.prepareStatement(Select);) {
                        ResultSet rs = pss.executeQuery();
                        System.out.println("ID" + "\t Developer" + "\t \t Description");
                        while (rs.next()) {
                            System.out.println(rs.getInt("id_developer") + "\t " + rs.getString("dev_name") + "\t \t " + rs.getString("description"));
                        }
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 4:
                    Select = "select * from publisher";
                    try (PreparedStatement pss = conn.prepareStatement(Select);) {
                        ResultSet rs = pss.executeQuery();
                        System.out.println("ID" + "\t Publisher" + "\t \t \t description");
                        while (rs.next()) {
                            System.out.println(rs.getInt("id_publisher") + "\t " + rs.getString("pub_name") + "\t \t \t " + rs.getString("description"));
                        }
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                default:
                    System.out.println("Niste unijeli validan broj");
                    break;
            }
            System.out.println("0 Prekinete akciju:");
            System.out.println("1 Prikazite zanrove:");
            System.out.println("2 Prikazi igrice:");
            System.out.println("3 Prikazi developere:");
            System.out.println("4 Prikazite publishere:");
            x1 = sc.nextInt();
        }
    }

    private static void updateFunction() throws SQLException {
        String Update;
        Connection conn = getConnection();
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Sta zelite da uradite:");
        System.out.println("0 Prekinete unos:");
        System.out.println("1 Updejtajte postojeci zanr:");
        System.out.println("2 Updejtajte postojecu igricu:");
        System.out.println("3 Updejtajte postojeceg developera:");
        System.out.println("4 Updejtajte postojeceg publishera:");
        int x1 = sc.nextInt();
        while (x1 != 0) {
            switch (x1) {
                case 1:

                    Update = "UPDATE genre SET genre_name = ? where id_genre=?";

                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Update);
                        System.out.println("Unesite id podatka koji zelite da unesete");
                        int x = sc.nextInt();
                        ps1.setInt(2, x);
                        System.out.println("Unesite novo ime zanra:");
                        ps1.setString(1, sc.next());

                        ps1.executeUpdate();
                        System.out.println("Updejtvoali ste zanr sa id-om " + x);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 2:
                    Update = "UPDATE game SET game_name = ?, game_price = ?, game_description = ?,game_rating = ?,"
                            + " developer_id=?, publisher_id = ?, genre_id = ? WHERE id_game =?";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Update);
                        System.out.println("Unesite id podatka koji zelite da unesete");
                        int x = sc.nextInt();
                        ps1.setInt(8, x);
                        System.out.println("Unesite novo ime igrice:");
                        ps1.setString(1, sc.next());
                        System.out.println("Unesite novu cijenu igrice:");
                        ps1.setString(2, sc.next());
                        System.out.println("Unesite novi opis igrice:");
                        ps1.setString(3, sc.next());
                        System.out.println("Unesite novi rating igrice (od 1-5):");
                        ps1.setFloat(4, sc.nextFloat());
                        System.out.println("Unesite novi developer id:");
                        ps1.setInt(5, sc.nextInt());
                        System.out.println("Unesite novi publisher id:");
                        ps1.setInt(6, sc.nextInt());
                        System.out.println("Unesite  novi genre id:");
                        ps1.setInt(7, sc.nextInt());
                        ;
                        ps1.executeUpdate();
                        System.out.println("Updejtovali ste igricu sa id-om " + x);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 3:
                    Update = "UPDATE developer SET dev_name =? , description =? WHERE id_developer =?";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Update);
                        System.out.println("Unesite id podatka koji zelite da unesete");
                        int x = sc.nextInt();
                        ps1.setInt(3, x);
                        System.out.println("Unesite novi naziv developera:");
                        ps1.setString(1, sc.next());
                        System.out.println("Unesite novi kratak opis developera:");
                        ps1.setString(2, sc.next());
                        ps1.executeUpdate();
                        System.out.println("Updejtovali ste deveopera sa id-om " + x);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 4:
                    Update = "UPDATE publisher SET pub_name = ?, description = ? WHERE id_publisher = ?";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Update);
                        System.out.println("Unesite id podatka koji zelite da unesete");
                        int x = sc.nextInt();
                        ps1.setInt(3, x);
                        System.out.println("Unesite novi naziv publishera:");
                        ps1.setString(1, sc.next());
                        System.out.println("Unesite novi kratak opis publishera:");
                        ps1.setString(2, sc.next());
                        ps1.executeUpdate();
                        System.out.println("Updejtovali ste publishera sa id-om " + x);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                default:
                    System.out.println("Niste unijeli validan broj");
                    break;
            }
            System.out.println("Sta zelite da uradite:");
            System.out.println("0 Prekinete unos:");
            System.out.println("1 Updejtajte postojeci zanr:");
            System.out.println("2 Updejtajte postojecu igricu:");
            System.out.println("3 Updejtajte postojeceg developera:");
            System.out.println("4 Updejtajte postojeceg publishera:");
            x1 = sc.nextInt();
        }

    }

    private static void deleteFunction() throws SQLException {
        String Delete;
        Connection conn = getConnection();
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Sta zelite da uradite:");
        System.out.println("0 Prekinete unos:");
        System.out.println("1 Izbrisite zanr:");
        System.out.println("2 Izbrisite igricu:");
        System.out.println("3 Izbrisite developera:");
        System.out.println("4 Izbrisite publishera:");
        int x1 = sc.nextInt();
        while (x1 != 0) {
            switch (x1) {
                case 1:

                    Delete = "DELETE FROM genre WHERE id_genre=?";

                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Delete);
                        System.out.println("Unesite id zanra koji zelite da izbrisete");
                        ps1.setInt(1, sc.nextInt());
                        ps1.executeUpdate();
                        System.out.println("Izbrisali ste zanr");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 2:
                    Delete = "DELETE FROM game WHERE id_game = ?";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Delete);
                        System.out.println("Unesite id igre koju zelite da izbrisete");
                        ps1.setInt(1, sc.nextInt());
                        ps1.executeUpdate();
                        System.out.println("Izbrisali ste igru");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 3:
                    Delete = "DELETE FROM developer WHERE id_developer = ?";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Delete);
                        System.out.println("Unesite id developera kojeg zelite da izbrisete");
                        ps1.setInt(1, sc.nextInt());
                        ps1.executeUpdate();
                        System.out.println("Izbrisali ste developera");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                case 4:
                    Delete = "DELETE FROM publisher WHERE id_publisher = ?";
                    try {
                        PreparedStatement ps1 = conn.prepareStatement(Delete);
                        System.out.println("Unesite id publishera kojeg zelite da izbrisete");
                        ps1.setInt(1, sc.nextInt());
                        ps1.executeUpdate();
                        System.out.println("Izbrisali ste publishera");
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    break;
                default:
                    System.out.println("Niste unijeli validan broj");
                    break;
            }
            System.out.println("Sta zelite da uradite:");
            System.out.println("0 Prekinete unos:");
            System.out.println("1 Izbrisite zanr:");
            System.out.println("2 Izbrisite igricu:");
            System.out.println("3 Izbrisite developera:");
            System.out.println("4 Izbrisite publishera:");
            x1 = sc.nextInt();
        }

    }
}
